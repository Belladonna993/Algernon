package algernon2;

public class MazeRunner {
	static final int ROWS = 20;
	static final int COLS = 40;
	static MazeSpace[][] maze = new MazeSpace[ROWS][COLS];


	static void printMaze() {
		printMaze(maze);
	}

	public static void printMaze(MazeSpace[][] aMaze) {
		System.out.println();
		for (int i = 0; i < ROWS; ++i) {
			for (int j = 0; j < COLS; ++j) {
				System.out.print(aMaze[i][j].getSymbol());
			}
			System.out.println();
		}
		System.out.println();
		
	}


	static void setupMaze(char[][] b) {
		for (int i = 0; i < b.length; ++i) {
			for (int j = 0; j < b[i].length; ++j) {
				maze[i][j] = MazeSpace.getMazeSpace(b[i][j]);
			}
		}
	}

	public static void main(String[] args) {
		Algernon mouse = new Algernon();

		System.out.print("=================\n");
		setupMaze(Mazes.MAZE01);
		printMaze();
		mouse.algernon();
		printMaze();

		System.out.print("=================\n");
		setupMaze(Mazes.MAZE02);
		printMaze();
		mouse.algernon();
		printMaze();

		System.out.print("=================\n");
		setupMaze(Mazes.MAZE03);
		printMaze();
		mouse.algernon();
		printMaze();
	
		System.out.print("=================\n");
		setupMaze(Mazes.MAZE04);
		printMaze();
		mouse.algernon();
		printMaze();

		System.out.print("=================\n");
		setupMaze(Mazes.MAZE05);
		printMaze();
		mouse.algernon();
		printMaze();

		System.out.print("=================\n");

	}

}
