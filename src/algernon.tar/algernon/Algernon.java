package algernon;

import java.util.Arrays;

public class Algernon {
	private MazeSpace[][] maze;
	private boolean startFound = false;
	// private boolean boundsReached = false;
	private int startRow, startCol;

	/*
	 * Write a function
	 * 
	 * void algernon(...)
	 * 
	 * that finds the shortest path in a maze represented by a 2D array of
	 * Things (where spaces represent potential paths, walls can never be paths,
	 * and flowers mark the solution path). Also in the maze is a single start
	 * element and a single cheese element. Lastly, you can temporarily set
	 * elements of the maze to U, D, L, or R to aid in your task, but those
	 * should be removed and set to something else before returning.
	 * 
	 * No diagonal moves are allowed; only up, down, left, and right.
	 * 
	 * In your function, you are given a static 2D array of Things called
	 * maze[ROWS][COLS]. The initial maze has only spaces, walls, a single start
	 * element, and a single cheese element -- no flowers.
	 * 
	 * Additionally, all array elements around the perimeter are guaranteed to
	 * be constructed solely of walls.
	 * 
	 * Your function should replace each space element along the shortest path
	 * from start to cheese with a flower and then return.
	 * 
	 * If no path exists, the maze is to remain unaltered.
	 * 
	 * Please make good use of functions, comments, and indentation to keep your
	 * code easily readable. No errors or warnings when compiling.
	 * 
	 * What to turn in: algernon.cpp and nothing else.
	 */

	MazeSpace[][] algernon(MazeSpace[][] maze) {
		this.maze = maze;

		growTheBlob();

		if (startFound) {
			plantTheFlowers();
		}
		
		clearTheRest();

		return this.maze;
	}



	private void growTheBlob() {
		while (!startFound) {
			MazeSpace[][] temp = Arrays.copyOf(maze, maze.length);

			for (int i = 0; i < maze.length; i++) {
				for (int j = 0; j < maze[i].length; j++) {
					if (maze[i][j] == MazeSpace.cheese || maze[i][j] == MazeSpace.D || maze[i][j] == MazeSpace.U
							|| maze[i][j] == MazeSpace.L || maze[i][j] == MazeSpace.R) {
						// check left
						if (maze[i][j - 1] == MazeSpace.start) {
							startFound = true;
							startRow = i;
							startCol = j - 1;
						}
						if (maze[i][j - 1] == MazeSpace.start || maze[i][j - 1] == MazeSpace.space) {
							temp[i][j - 1] = MazeSpace.R;
						}
						// check right
						if (maze[i][j + 1] == MazeSpace.start) {
							startFound = true;
							startRow = i;
							startCol = j + 1;
						}
						if (maze[i][j + 1] == MazeSpace.start || maze[i][j + 1] == MazeSpace.space) {
							temp[i][j + 1] = MazeSpace.L;
						}
						// check up
						if (maze[i - 1][j] == MazeSpace.start) {
							startFound = true;
							startRow = i - 1;
							startCol = j;
						}
						if (maze[i - 1][j] == MazeSpace.start || maze[i - 1][j] == MazeSpace.space) {
							temp[i - 1][j] = MazeSpace.D;
						}
						// check down
						if (maze[i + 1][j] == MazeSpace.start) {
							startFound = true;
							startRow = i + 1;
							startCol = j;
						}
						if (maze[i + 1][j] == MazeSpace.start || maze[i + 1][j] == MazeSpace.space) {
							temp[i + 1][j] = MazeSpace.U;
						}
					}
				}
				maze = temp;
				MazeRunner.printMaze(maze);
			}

		}

	}

	private void plantTheFlowers() {
		MazeSpace temp = maze[startRow][startCol];
		int newRow = startRow;
		int newCol = startCol;

		while (temp != MazeSpace.cheese) {
			maze[newRow][newCol] = MazeSpace.flower;

			switch (temp) {
			case L:
				newCol--;
				break;
			case R:
				newCol++;
				break;
			case U:
				newRow--;
				break;
			case D:
				newRow++;
				break;
			default:
				break;
			}
			
			temp = maze[newRow][newCol];
			//MazeRunner.printMaze(maze);
		}

	}
	
	private void clearTheRest() {
		for (int i = 0; i < maze.length; i++) {
			for (int j = 0; j < maze[i].length; j++) {
				if (maze[i][j] == MazeSpace.L || maze[i][j] == MazeSpace.R || maze[i][j] == MazeSpace.U || maze[i][j] == MazeSpace.D) {
					maze[i][j] = MazeSpace.space;
				}
			}
		}
		
	}

}
