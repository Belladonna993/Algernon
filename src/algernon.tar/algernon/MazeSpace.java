package algernon;

import java.util.HashMap;
import java.util.Map;

public enum MazeSpace {
	space(' '), 
	wall('X'), 
	flower('*'), 
	start('S'), 
	cheese('C'), 
	U('U'), 
	D('D'), 
	L('L'), 
	R('R');
	
	private char symbol;
	
	MazeSpace(char symbol){
		this.symbol = symbol;
	}
	
	char getSymbol() {
		return symbol;
	}
	
    private static Map<Character, MazeSpace> symbolToSpaceMap;
    
    public static MazeSpace getMazeSpace(char c) {
        if (symbolToSpaceMap == null) {
            initMapping();
        }
        return symbolToSpaceMap.get(c);
    }
 
    private static void initMapping() {
    	symbolToSpaceMap = new HashMap<Character, MazeSpace>();
        for (MazeSpace space : values()) {
        	symbolToSpaceMap.put(space.symbol, space);
        }
    }

}
